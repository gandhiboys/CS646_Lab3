package com.zybooks.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random
import android.content.Intent


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val flipButton = findViewById<Button>(R.id.flipButton)
        val coinImageView = findViewById<ImageView>(R.id.coinImageView)

        flipButton.setOnClickListener {
            // Generate a random number (0 or 1) to simulate coin flip
            val randomNumber = Random.nextInt(2)

            // Set the appropriate image based on the random number
            val drawableResource = if (randomNumber == 0) {
                R.drawable.heads
            } else {
                R.drawable.tails
            }
            coinImageView.setImageResource(drawableResource)

            // Show result in an AlertDialog
            val resultText = if (randomNumber == 0) {
                getString(R.string.heads_result)
            } else {
                getString(R.string.tails_result)
            }
            showResultDialog(resultText)
        }

        // Add click listener for settings button
        val settingsButton = findViewById<Button>(R.id.settingsButton)
        settingsButton.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)

        }
    }

    private fun showResultDialog(result: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.result_title))
        builder.setMessage(result)
        builder.setPositiveButton(getString(R.string.ok_button)) { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }


}
